(function(_global){
	
	//define
	var fullScreenUtil = {
			whatisjquery:function(){
				console.log("jquery is ",$)
			},
		}

	if (wilas){
		var moduleName = "wilas.util.fullScreenUtil";
		var deps = ["jquery"];
		fullScreenUtil.moduleName = moduleName;
		if (wilas.support && typeof wilas.support == "function"){
			wilas.support(fullScreenUtil,deps);
		}
		// if(wilas.createNormalModule && typeof wilas.createNormalModule == "function"){
		// 	fullScreenUtil = wilas.createNormalModule(fullScreenUtil);
		// }
		// if(wilas.supportAMD && typeof wilas.supportAMD == "function"){
		// 	wilas.supportAMD(deps,fullScreenUtil);
		// }
	}
})(window);